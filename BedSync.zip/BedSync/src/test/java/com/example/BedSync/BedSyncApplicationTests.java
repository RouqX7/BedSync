package com.example.BedSync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BedSyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
