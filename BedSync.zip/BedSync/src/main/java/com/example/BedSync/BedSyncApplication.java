package com.example.BedSync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BedSyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(BedSyncApplication.class, args);
	}

}
